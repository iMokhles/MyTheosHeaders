//
//  @@PROJECTNAME@@Module.h
//  @@FULLPROJECTNAME@@
//
//  Created by @@USER@@ on @@DATE@@.
//  Copyright (c) @@YEAR@@ @@USER@@. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <JavaScriptCore/JavaScriptCore.h>

@interface SCModule : NSObject

- (instancetype)initWithContext:(JSContext *)context;

@end


@interface @@PROJECTNAME@@Module : SCModule

@end
