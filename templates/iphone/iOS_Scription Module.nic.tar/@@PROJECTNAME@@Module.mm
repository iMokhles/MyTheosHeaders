//
//  @@PROJECTNAME@@Module.mm
//  @@FULLPROJECTNAME@@
//
//  Created by @@USER@@ on @@DATE@@.
//  Copyright (c) @@YEAR@@ @@USER@@. All rights reserved.
//

#import "@@PROJECTNAME@@Module.h"

@implementation @@PROJECTNAME@@Module

- (instancetype)initWithContext:(JSContext *)context
{
	self = [super initWithContext:context];

	return self;
}

@end
