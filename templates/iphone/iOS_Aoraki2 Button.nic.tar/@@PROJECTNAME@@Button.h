//
//  @@PROJECTNAME@@Module.h
//  @@FULLPROJECTNAME@@
//
//  Created by @@USER@@ on @@DATE@@.
//  Copyright (c) @@YEAR@@ @@USER@@. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class CNPGridMenuItem;
typedef void (^SelectionHandler)(CNPGridMenuItem *item);

@interface CNPGridMenuItem : NSObject
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) UIImage *icon;
@property (nonatomic, copy) SelectionHandler selectionHandler;
@end

@interface Aoraki2Window : UIWindow
+ (Aoraki2Window *)sharedWindow;
- (void)closeWindow;
@end

@interface @@PROJECTNAME@@Button : CNPGridMenuItem

@end
